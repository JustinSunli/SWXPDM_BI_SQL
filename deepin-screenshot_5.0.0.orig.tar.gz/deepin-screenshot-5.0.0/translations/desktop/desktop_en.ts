<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
    <context>
        <name>desktop</name>
        <message>
            <location filename="Desktop Entry]Name" line="0"/>
            <source>Deepin Screenshot</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <location filename="Delay_Screenshot Shortcut Group]Name" line="0"/>
            <source>Delay Screenshot</source>
            <translation type="unfinished"/>
        </message>
        <message>
            <location filename="Full_Screenshot Shortcut Group]Name" line="0"/>
            <source>Full Screenshot</source>
            <translation>Full Screenshot</translation>
        </message>
        <message>
            <location filename="Desktop Entry]Comment" line="0"/>
            <location filename="Desktop Entry]GenericName" line="0"/>
            <source>Screen capturing application</source>
            <translation type="unfinished"/>
        </message>
    </context>
</TS>
